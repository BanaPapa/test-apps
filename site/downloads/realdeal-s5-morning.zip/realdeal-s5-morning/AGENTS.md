# 아침 보고 · AI 작업 지시서

이 폴더는 **아침 보고** 앱을 만들기 위한 키트다. 너(AI 코딩 도우미)는 이 폴더의 문서대로 앱을 끝까지 완성한다.

> 지켜보는 동네들에 지난 확인 이후 새로 확인된 아파트 거래를 매일 아침 8시 슬랙으로 보내 주는 앱. 목록은 앱이, 요약 두 문장은 분석 모델이 쓴다.

## 사용자가 "만들어줘", "설치해줘", "진행해줘", "이대로 코딩해줘" 라고 하면

1. 아래 **읽는 순서**대로 문서를 모두 읽는다. 건너뛰지 않는다.
2. `node -v` 로 Node.js 버전을 확인한다. **22 이상**이어야 한다. 없거나 낮으면 https://nodejs.org 에서 LTS 를 설치하라고 안내하고 멈춘다.
3. `docs/BUILD_PLAN.md` 의 0단계부터 마지막 단계까지 **멈추지 말고** 진행한다. 단계마다 그 단계의 "확인"을 실제로 해 보고, 실패하면 고친 뒤 다시 확인한다.
4. 사람이 직접 해야 하는 일(인증키 발급, 결제 등록, GitHub Secrets 입력)은 그 단계에서 짧게 안내만 하고, **키가 없어도 예시 데이터로 계속 진행한다.** 키가 있어야만 확인할 수 있는 항목은 마지막 보고에 "키를 넣은 뒤 확인할 것"으로 모은다.
5. 끝나면 아래 **마지막 보고** 형식으로 알린다.

중간에 사용자에게 묻는 것은 문서끼리 서로 어긋나거나, 문서에 없는 결정을 해야 할 때만이다.

## 읽는 순서

1. `docs/PRD.md`: 무엇을, 누구를 위해, 완료 기준
2. `docs/STACK.md`: 기술 스택, 폴더, 제공된 부품, 공통 규칙
3. `docs/FSD.md`: 기능 명세 (함수 이름·형식·규칙이 정해져 있다. 그대로 따른다)
4. `docs/DESIGN.md` 와 `design/mockup.html`: 화면. mockup 은 브라우저로 열어 보거나 소스를 읽는다. **mockup 의 숫자는 예시**이고 실제 숫자는 계산해서 넣는다
5. `docs/API_MOLIT.md`: 국토부 API 와 제공된 데이터 부품
6. `docs/API_LLM.md`: 분석 모델 연결, 글을 쓰게 하는 순서, 숫자 대조
7. `docs/AUTOMATION.md`: 매일 자동 실행, 스냅샷 비교, GitHub Secrets
8. `docs/BUILD_PLAN.md`: 단계별 작업 순서와 확인

## 지켜야 할 것

- **제공된 부품은 고치지 않는다.** `lib/molit.ts`, `lib/stats.ts`, `lib/regions.ts`, `lib/sample.ts`, `lib/client.ts`, `lib/constants.ts`, `lib/months.ts`, `app/api/molit/route.ts`, `lib/llm.ts`, `lib/llm-client.ts`, `lib/number-check.ts`, `app/api/llm/route.ts`, `lib/snapshot.ts`, `lib/slack.ts`, `lib/env.ts`, `.github/workflows/daily.yml` 과 `tests/` 의 기존 테스트, `data/`. 실제 응답으로 검증된 코드다. 꼭 고쳐야 한다면 먼저 이유를 사용자에게 말한다.
- **범위를 넓히지 않는다.** PRD 의 "하지 않는 것"은 만들지 않는다. 더 좋아 보이는 기능이 떠올라도 마지막 보고에 제안으로만 적는다.
- **패키지를 더 설치하지 않는다.** STACK.md 1절 밖의 라이브러리가 필요해 보이면 먼저 묻는다.
- **키를 파일에 쓰지 않는다.** 인증키·API 키·Webhook 주소는 화면 입력(localStorage), `.env.local`, GitHub Secrets 에만 둔다.
- **문서가 코드보다 우선한다.** 문서와 다르게 만들어야 할 이유가 생기면 그렇게 하기 전에 사용자에게 알린다.
- 우선순위: 시나리오 문서(PRD·FSD·DESIGN·BUILD_PLAN) > STACK.md > 일반적인 관례.

## 마지막 보고 형식

```
## 완성했습니다: 아침 보고

실행: npm run dev → http://localhost:3000
확인한 것: npm test (n개 통과), npm run build 성공, 예시 데이터로 핵심 흐름 확인
PRD 완료 기준: (항목마다 ✔ 또는 "키를 넣은 뒤 확인할 것")

사용자가 할 일:
1. (예: 공공데이터포털 인증키를 화면 오른쪽 위 칸에 넣기)
2. ...

다음에 해 볼 만한 것: (있으면 1~3개)
```
